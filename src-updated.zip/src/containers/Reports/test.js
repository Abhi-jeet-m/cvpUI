import React, { Component } from 'react';

class Test extends Component{
    render(){
        return(
            <div>
                <h1>This is the test sample for leftside dashboard panel</h1>
            </div>
        )
    }
}

export default Test