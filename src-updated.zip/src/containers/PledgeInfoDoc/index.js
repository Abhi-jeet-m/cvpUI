import PledgeInfoDoc from './PledgeInfoDoc';

export default PledgeInfoDoc;
