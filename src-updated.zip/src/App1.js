import React from 'react';
import Routes from './routes1';
import './App.scss';


const App1 = () => <div className="CVP">{ Routes }</div>;

export default App1;
